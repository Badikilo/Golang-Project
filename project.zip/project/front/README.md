
  # golang

  This is a code bundle for golang. The original project is available at https://www.figma.com/design/fixriq9oYprYeRfv7qLLeu/golang.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  